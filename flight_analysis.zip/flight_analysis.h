#ifndef ___FLIGHTANALYSIS_H___
#define ___FLIGHTANALYSIS_H___

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>


int ler_ficheiro(double parametros[], char* name[]);

void printParametros (double parametros[], char* nome_parametros[]);


#endif
