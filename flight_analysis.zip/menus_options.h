#ifndef ___MENUSOPTIONS_H___
#define ___MENUSOPTIONS_H___

int run_menu(int opcao, int menu_number);

void menu (int menu_number);

void writeMenu(char* MENU[], int tamanho);

#endif